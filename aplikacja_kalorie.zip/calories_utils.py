# Obliczenia kalorii i indeks glikemiczny
