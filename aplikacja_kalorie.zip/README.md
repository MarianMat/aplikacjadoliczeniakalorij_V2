# Aplikacja Kalorie

Streamlitowa aplikacja do liczenia kalorii z loginem, kodami kreskowymi i AI.