# Główny plik aplikacji Streamlit

import streamlit as st
st.title('Aplikacja liczenia kalorii')
