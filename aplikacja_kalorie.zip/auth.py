# Autoryzacja użytkowników
