# Obsługa zdjęć i AI
