# Skanowanie kodów kreskowych
